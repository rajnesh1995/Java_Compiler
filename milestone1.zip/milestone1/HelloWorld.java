public class HelloWorld
{
	public static void main(String []args)
	{
		int a;
		a=10;
		int b;
		b=a+20;
	}
}
